---
name: m2m-campaign-production
description: Produce a complete M2M campaign from evidence and strategy through final copy, Higgsfield-led creative, native channel exports, email and website designs, campaign calendar, lead magnet, provenance, QA and a private review release. Use when James asks for a comprehensive, end-to-end, production-ready or fully developed M2M campaign pack; when copy and creative must be carried through to completion; or when an outline or campaign hub must become a real production system. Do not use for a short executive campaign summary alone; use campaign-hub for that smaller job.
---

# M2M campaign production

Deliver the campaign, not another description of the campaign.

Use this skill when the requested outcome is a complete copy-and-creative pack. A
finished run gives reviewers enough evidence and artwork to decide whether to
activate the campaign without sending them to reconstruct missing emails,
formats, landing treatments or claim controls.

## Read first

Read these references before production:

1. `references/production-standard.md`
2. `references/evidence-and-gates.md`
3. `references/higgsfield-creative-workflow.md` when the campaign includes generated imagery or motion
4. `references/output-contract.md`

Use `assets/starter/campaign-brief.example.json` as a structural starting point,
not as content to carry into a new campaign.

## Mode boundary

Keep these two deliverables distinct:

- `campaign-hub`: an executive, two-to-three-minute overview that links out.
- `m2m-campaign-production`: the full production pack with complete copy,
  creative, formats, activation designs, evidence, manifests and QA.

If James points to a complete campaign pack as the model, match its depth and
review utility rather than copying its brand, subject matter or visual motif.

## Required workflow

1. **Recover truth.** Inspect the live destination, current campaign record,
   supplied brief, authoritative product sources, current brand pack, target
   audience and prior work. Separate confirmed facts from proposals and gaps.
2. **Lock the conversion object.** Define one commercial objective, one primary
   audience decision, one conversion route and one primary CTA. Name the live
   destination or label it unverified.
3. **Build the narrative system.** Set the campaign phases, cadence, weekly or
   thematic progression, channel roles and measurement model before rendering.
4. **Write complete copy.** Finish every social caption, carousel frame, email,
   web treatment, paid unit, retargeting unit and sales talk track in the scope.
   Do not mark a channel ready when only a headline or placeholder exists.
5. **Create the visual system.** Use official logos, fonts and tokens. Generate
   text-free Higgsfield photographic or illustrative masters where useful, then
   apply all branding and copy deterministically in code.
6. **Render native outputs.** Produce the real aspect ratios for each named
   channel, plus email designs, website treatments in situ and motion where it
   materially improves the campaign.
7. **Make the conversion object real.** Build the promised guide, checklist,
   calculator, form concept or other lead asset. A CTA to a missing object is a
   failed pack.
8. **Assemble the review surface.** Put strategy, calendar, creative, full copy,
   website/email context, provenance, evidence, limitations and gates in one
   coherent private page.
9. **Verify artefacts, not commands.** Run the validator, browser checks,
   mobile checks, broken-resource checks and page-by-page PDF inspection. Fix
   clipped copy, unsafe crops and overflow before reporting completion.
10. **Publish only the authorised layer.** A private no-index review deployment
    does not authorise live web changes, social scheduling, email sends, paid
    spend, CRM mutation, pricing commitments or external communication.

## Non-negotiable creative rules

- Place the supplied official logo; never redraw, recolour or ask an image model
  to render it.
- Do not ask a generative image model to typeset final campaign copy.
- Preserve a text-free master and a deterministic branded export.
- Retain the prompt brief, model, date, source references, rights status,
  output path and SHA-256 receipt for every generated master.
- Treat a supplied reference image as mood/composition evidence unless its
  publication rights are explicitly confirmed.
- Build each composition for its native crop. A resized master is not
  automatically a platform-ready creative.
- Use Australian English and M2M's current brand voice unless the controlling
  brief says otherwise.

## Completion test

Do not call a pack production-ready unless all applicable lines pass:

- strategy, audience, offer, conversion route and phase logic are explicit;
- every listed asset has complete copy and a final visual or an honest blocked state;
- social channels and native dimensions are named;
- email body copy and email designs both exist;
- website activation is shown in situ, not merely described;
- the calendar connects date, channel, asset, purpose, owner/state and CTA;
- the lead/conversion object exists and opens;
- technical, safety, pricing and performance claims have provenance and limits;
- generated creative has rights/provenance receipts;
- desktop, 390 px, 320 px, 200% zoom and print/PDF checks pass where applicable;
- asset links resolve, manifests match files and no secret or placeholder leaked;
- the review surface says what is ready, proposed, blocked and not authorised;
- activation remains separately gated.

Run the bundled validator before handoff:

```bash
python3 scripts/verify_campaign_pack.py <campaign-pack-directory>
```

The validator is a floor, not a substitute for visual inspection.
