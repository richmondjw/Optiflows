#!/usr/bin/env python3
"""Static acceptance-floor validator for an M2M production campaign pack."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import sys
from pathlib import Path


PLACEHOLDERS = re.compile(r"\b(TODO|TBC|LOREM IPSUM|REPLACE[_ -]?ME|YOUR[_ -]?CTA)\b", re.I)
SECRET_PATTERNS = [
    re.compile(r"(?i)(api[_-]?key|client[_-]?secret|access[_-]?token|refresh[_-]?token)\s*[:=]\s*['\"]?[A-Za-z0-9_\-]{16,}"),
    re.compile(r"\bops_[A-Za-z0-9._-]{40,}\b"),
    re.compile(r"\bgh[pousr]_[A-Za-z0-9]{30,}\b"),
]
IGNORED_DIRS = {".git", "node_modules", "tmp", "__pycache__"}


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def files_under(root: Path):
    for path in root.rglob("*"):
        relative_parts = path.relative_to(root).parts
        if path.is_file() and not any(part in IGNORED_DIRS for part in relative_parts):
            yield path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("pack", type=Path)
    args = parser.parse_args()
    root = args.pack.resolve()
    failures: list[str] = []
    warnings: list[str] = []

    required = ["index.html", "creative-provenance.json", "asset-manifest.json"]
    for relative in required:
        if not (root / relative).is_file():
            failures.append(f"missing required file: {relative}")

    structured = [root / "campaign-data.js", root / "campaign-data.json"]
    if not any(item.is_file() for item in structured):
        failures.append("missing structured campaign source: campaign-data.js or campaign-data.json")

    manuscripts = list((root / "downloads").glob("*manuscript.md")) if (root / "downloads").is_dir() else []
    if not manuscripts:
        failures.append("missing complete manuscript in downloads/")
    calendar = root / "downloads" / "campaign-calendar.csv"
    if not calendar.is_file():
        failures.append("missing downloads/campaign-calendar.csv")
    else:
        with calendar.open(encoding="utf-8", newline="") as handle:
            rows = list(csv.DictReader(handle))
        if not rows:
            failures.append("campaign calendar has no rows")
        expected = {"week", "date", "phase", "channel", "asset", "purpose", "state"}
        if rows and not expected.issubset(rows[0]):
            failures.append("campaign calendar is missing required columns")

    index = root / "index.html"
    if index.is_file():
        html = index.read_text(encoding="utf-8")
        robot_match = re.search(r'<meta\s+name=["\']robots["\'][^>]*content=["\']([^"\']+)', html, re.I)
        if not robot_match or "noindex" not in robot_match.group(1).lower() or "nofollow" not in robot_match.group(1).lower():
            failures.append("review page must declare noindex,nofollow")
        boundary_words = ("not activated", "activation")
        if not all(word in html.lower() for word in boundary_words):
            failures.append("review page does not expose the activation boundary")

        local_refs = re.findall(r'(?:src|href)=["\']([^"\'#?]+)', html, re.I)
        for ref in local_refs:
            if "${" in ref or ref == "../":
                continue
            if ref.startswith(("http://", "https://", "mailto:", "tel:", "/")):
                continue
            target = (root / ref).resolve()
            try:
                target.relative_to(root)
            except ValueError:
                failures.append(f"path escapes pack: {ref}")
                continue
            if not target.exists():
                failures.append(f"broken local link: {ref}")

    manifest_path = root / "asset-manifest.json"
    if manifest_path.is_file():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            items = manifest.get("files", [])
            if not items:
                failures.append("asset manifest contains no files")
            for item in items:
                relative = item.get("file", "")
                target = root / relative
                if not target.is_file():
                    failures.append(f"manifest file missing: {relative}")
                    continue
                if item.get("sha256") != digest(target):
                    failures.append(f"hash mismatch: {relative}")
        except (json.JSONDecodeError, TypeError) as error:
            failures.append(f"invalid asset manifest: {error}")

    provenance_path = root / "creative-provenance.json"
    if provenance_path.is_file():
        try:
            provenance = json.loads(provenance_path.read_text(encoding="utf-8"))
            if not provenance.get("imageMasters"):
                warnings.append("provenance has no generated image masters")
            for reference in provenance.get("references", []):
                if not reference.get("rightsStatus"):
                    failures.append(f"reference lacks rights state: {reference.get('file', 'unknown')}")
        except (json.JSONDecodeError, TypeError) as error:
            failures.append(f"invalid creative provenance: {error}")

    text_extensions = {".html", ".js", ".json", ".md", ".css", ".csv", ".txt", ".svg"}
    for path in files_under(root):
        if path.suffix.lower() not in text_extensions:
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        relative = path.relative_to(root)
        if PLACEHOLDERS.search(text) and "example" not in path.name.lower():
            warnings.append(f"possible placeholder: {relative}")
        for pattern in SECRET_PATTERNS:
            if pattern.search(text):
                failures.append(f"possible secret value: {relative}")

    print(f"pack={root}")
    print(f"files={sum(1 for _ in files_under(root))}")
    for warning in sorted(set(warnings)):
        print(f"WARN: {warning}")
    for failure in sorted(set(failures)):
        print(f"FAIL: {failure}")
    if failures:
        print(f"RESULT: FAIL ({len(set(failures))} unique issue(s))")
        return 1
    print(f"RESULT: PASS ({len(set(warnings))} warning(s))")
    return 0


if __name__ == "__main__":
    sys.exit(main())
