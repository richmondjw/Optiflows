# Higgsfield creative workflow

Use Higgsfield to create the visual material that benefits from generative
intelligence. Keep brand execution, typesetting and production control in the
deterministic renderer.

## 1. Prepare the visual brief

For each concept define:

- the campaign argument it must express;
- audience and operating context;
- subject, setting, camera position and time/light;
- emotional register;
- intended crops and required negative space;
- realism/safety constraints;
- prohibited additions;
- reference files and their rights state.

Prefer one clear photographic idea over a collage of product features.

## 2. Reference discipline

- Inspect every reference before use.
- Record whether it is official, licensed, user-supplied or found research.
- Record whether rights permit publication, reference-only use or neither.
- Use unknown-rights material for mood/composition only and keep it out of final exports.
- Avoid reproducing an identifiable photographer's composition too closely.
- Do not use a reference to imply a real deployment, customer or location when it is illustrative.

## 3. Image generation

Default to GPT Image 2 through the current Higgsfield generation workflow for
premium campaign masters. Use a reference-capable model when fidelity to an
approved product or subject is required.

Prompt for:

- text-free, logo-free masters;
- credible Australian environments where relevant;
- precise equipment/PPE/context constraints;
- controlled negative space for typography;
- coherent light, lens and colour intent;
- no fictitious UI, illegible labels or impossible engineering detail.

Generate concept-specific masters. Reusing a master is acceptable only when it
serves a deliberate return to the campaign's main argument.

## 4. Art direction and selection

Inspect outputs at original resolution. Reject:

- anatomically or mechanically implausible detail;
- incorrect safety equipment;
- visual spectacle that overstates the claim;
- generic “AI glow” or random interface overlays;
- a crop that cannot hold the approved copy;
- scenery that could misrepresent a real customer/location;
- artefacts near hands, antennas, wheels, wires or horizon lines.

Select for concept clarity, crop resilience and credibility—not merely beauty.

## 5. Deterministic finishing

Apply official logo files, approved typefaces, brand colour, overlays and final
copy in HTML/CSS, SVG or another deterministic production system. Keep:

- raw generated master;
- editable render source;
- native exports;
- asset manifest;
- provenance record.

Never rely on a model-rendered logo or model-rendered campaign headline.

## 6. Motion

Use image-to-video only when movement adds meaning or premium attention value.
Seedance 2.0 is the default for short campaign studies unless the current
Higgsfield tooling recommends a better model.

Motion briefs should:

- preserve source geometry and identity;
- specify one controlled camera move;
- constrain natural movement;
- prohibit added objects, copy and logos;
- avoid unsupported product behaviour;
- produce a muted loop and poster frame for web review.

Check first frame, middle frame, last frame, loop seam, encoding, file weight and
mobile autoplay behaviour. Do not let decorative movement obscure copy.

## 7. Receipt

For every master retain:

- final file path and SHA-256;
- provider and model;
- generation date;
- prompt brief (or verbatim prompt when available);
- source/reference paths and rights state;
- job identifier when available;
- selection/edit notes;
- deterministic derivatives;
- limitations.

Do not retain expiring asset URLs or credentials as the only provenance.

