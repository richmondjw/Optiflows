# Output contract

## Recommended package

```text
campaigns/<campaign-slug>/
  index.html                         # private review surface
  campaign-data.js|json              # structured source of truth
  creative-provenance.json
  asset-manifest.json
  render.html                        # deterministic export surface
  assets/
    brand/                           # official placed assets
    fonts/
    reference-art/                   # never imply publication rights
    higgsfield-masters/              # text-free generative sources
    exports/                         # channel-native stills
    carousels/
    email/
    website/
    motion/
  downloads/
    <date>-<campaign>-manuscript.md
    campaign-calendar.csv
    <conversion-object>.pdf
  tools/
    render-assets.*
    verify-*.py|js
```

Do not add empty directories merely to match the tree. Add each applicable
surface and state honest exclusions.

## Minimum structured fields

### Campaign

- id, title, owner, version, state, proposed/live dates;
- objective, audiences, positioning line, conversion route;
- primary CTA/destination, primary measure and non-goal;
- phases and calendar;
- evidence sources and activation gates.

### Social asset

- concept/week, phase, date, platform/channel;
- eyebrow, headline, support, CTA and full caption;
- destination, hashtags where used, evidence note;
- native output filenames.

### Email

- id/week, segment, subject, preheader, headline;
- complete paragraphs and bullets;
- CTA label and URL;
- design filename and proposed variables.

### Creative receipt

- source/master/derivative relationship;
- official/referenced/generated state;
- rights state;
- provider/model/date/prompt brief where generated;
- SHA-256 and limitations.

## Review-page requirements

- `noindex,nofollow,noarchive`;
- campaign state visible above the fold;
- no secret values or private contact data;
- complete copy reachable without source-file access;
- every downloadable link works;
- generated and reference assets truthfully labelled;
- activation boundary visible;
- desktop and mobile layouts;
- graceful motion fallback and reduced-motion behaviour.

## Manifest requirements

The asset manifest should include path, category, bytes, dimensions where
available, SHA-256, generation timestamp and exclusions. It may omit its own
hash. Counts on the review page must be reproducible from the package.

## Handoff statement

Report separately:

1. what was created;
2. what was technically verified;
3. what review URL was published;
4. what remains proposed or blocked;
5. what is explicitly not activated;
6. which decisions or credentials are genuinely still required.
