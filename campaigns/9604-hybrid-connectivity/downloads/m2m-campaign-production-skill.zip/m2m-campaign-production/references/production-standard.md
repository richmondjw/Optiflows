# Full campaign production standard

## Definition of done

A full production pack is a connected decision system:

`evidence → audience problem → campaign argument → channel copy → native creative → conversion object → review → separately authorised activation`

An attractive overview page is not sufficient. The pack must let a reviewer
inspect the actual words, actual designs, actual destination and actual release
conditions.

## Production sequence

### 1. Forensic intake

Inspect, in this order:

1. the live destination and current public claim;
2. the operational campaign/task record;
3. the authoritative product or service sources;
4. the current brand package and existing successful pack;
5. supplied references and their rights state;
6. previous campaign outputs and measured outcomes, if available.

Record contradictions. Do not silently choose the more convenient claim.

### 2. Campaign architecture

Write one sentence for each:

- commercial objective;
- primary audience and their decision;
- problem or tension;
- positioning line;
- conversion route;
- primary CTA;
- measurement hierarchy;
- explicit non-goal.

Then create a narrative arc. For a 90-day technical campaign, a useful default
is problem recognition, vertical proof and engineering conversion. Change it
when the evidence calls for a different journey.

### 3. Channel system

Give each channel a job. Avoid duplicating the same caption everywhere.

| Surface | Typical job |
|---|---|
| LinkedIn organic/document | Teach the argument and build technical trust |
| Email | Progress known contacts through the decision |
| Website | Hold the canonical explanation and conversion path |
| Paid search | Capture explicit problem/solution intent |
| Retargeting | Return engaged visitors to the next useful object |
| Sales/SI follow-up | Qualify a real use case and move into human dialogue |

Every scheduled touch needs a date, channel, specific asset/action, purpose,
state and destination. Add owner when known; label it `unassigned` when not.

### 4. Copy completion

For every social post retain:

- platform/channel;
- on-creative eyebrow, headline, support and CTA;
- full paste-ready caption;
- destination URL;
- evidence/claim guard;
- final asset filenames.

For every email retain:

- segment;
- subject and preheader;
- complete body copy;
- CTA label and URL;
- matching design;
- any proposed-only variables such as speaker, date or price.

For each website treatment show it in situ: hero, proof/architecture panel,
vertical proof, conversion module or other real touchpoint. Do not submit a box
labelled “website banner” as website activation design.

### 5. Design system

Derive a small system from current brand sources: palette, type, logo rules,
spacing, image treatment, headline behaviour and accessibility requirements.
Use one visual language across all channels while art-directing each concept.

The aim is controlled variation, not twelve copies of one template.

### 6. Review package

The primary review page should answer, in order:

1. What decision is this campaign trying to change?
2. Who is it for and why now?
3. How does the argument progress?
4. What runs, when and where?
5. What does every asset look and sound like?
6. How does the website and email experience carry it?
7. What evidence supports the claims?
8. What must happen before activation?

Use progressive disclosure for long copy, but keep all copy accessible in the
review artefact and downloadable manuscript.

## Quality threshold

- The campaign feels authored, not assembled.
- The art direction reinforces the argument.
- Copy and image hierarchy survive real channel crops.
- The full email is present, not merely a mock subject line.
- Website studies resemble the true destination context.
- A reader can distinguish final, proposed, unknown and blocked states.
- A reviewer can download the real artefacts without asking where they live.

## Failure patterns

- announcing “complete” when the pack contains an outline;
- counting copy fragments as production assets;
- sending reviewers to multiple disconnected folders;
- using generated typography or pseudo-logos;
- hiding a missing landing page behind a polished CTA;
- allowing stale pricing or product claims to propagate across every asset;
- treating a green renderer as proof that the design is not clipped;
- treating review-page publication as campaign activation.

