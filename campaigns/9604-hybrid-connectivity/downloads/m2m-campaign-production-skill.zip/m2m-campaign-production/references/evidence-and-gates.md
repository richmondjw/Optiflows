# Evidence, claims and release gates

## Evidence labels

Use these labels consistently:

- `confirmed`: directly observed in an authoritative current source;
- `strongly supported`: supported by multiple credible sources but not directly verified end to end;
- `inferred`: reasoned from evidence and clearly marked;
- `contradictory`: current sources disagree;
- `stale`: once valid but outside its decision-useful period;
- `unknown`: no adequate evidence;
- `unverifiable`: the required source or access is unavailable.

For each material product, performance, pricing, safety or availability claim,
retain source owner, URL/path, observation date, scope, limitation and confidence.

## Source order

Prefer:

1. current official product/service documentation;
2. current M2M-owned source of record;
3. verified live destination and instrumentation;
4. approved campaign decisions;
5. secondary research;
6. historical campaign material.

Historical creative can inspire treatment. It cannot establish a live fact.

## Claim controls

- Qualify technical behaviour that depends on customer implementation.
- Never turn a capability into an automatic outcome.
- Never turn a test result into universal performance.
- Never imply uninterrupted connectivity, guaranteed delivery or a safety
  guarantee unless an authoritative approved source explicitly supports it.
- Keep event dates, speakers, inventory, price and availability proposed until
  their named owners confirm them.
- Put the limitation close to the claim; do not bury it only in provenance.

## Human gates

These actions remain separately authorised even when the production pack is complete:

- external website publication or material production changes;
- email send, list upload or external message;
- social scheduling/publishing;
- paid-media budget or spend;
- CRM creation, enrichment, field mutation or sales assignment;
- price, discount, offer or commercial commitment;
- privacy, security, certification or safety assertions;
- event confirmation and external speaker commitment;
- credential, billing or account-recovery changes.

A private review deployment may be executed when James explicitly approves
that bounded publication. It must carry `noindex,nofollow` and clearly say that
activation is not authorised.

## Activation checklist

Before channel activation, require:

- one current campaign lifecycle and date record;
- destination URL and form working end to end;
- UTM/source capture proven into the agreed system;
- named lead owner and response SLA;
- technical/claim review complete;
- final audience/list approved;
- budget approved where applicable;
- privacy/consent obligations met;
- rollback/pause owner named;
- James's explicit release authority recorded.
